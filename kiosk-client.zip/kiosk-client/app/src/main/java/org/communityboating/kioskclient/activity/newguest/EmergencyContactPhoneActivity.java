package org.communityboating.kioskclient.activity.newguest;

import org.communityboating.kioskclient.R;
import org.communityboating.kioskclient.progress.newguest.ProgressStateEmergencyContactPhone;

public class EmergencyContactPhoneActivity extends GenericPhoneActivity<ProgressStateEmergencyContactPhone> {

    @Override
    public int getTitleTextID(){
        return R.string.act_title_ec;
    }

}
