package org.communityboating.kioskclient.config;

import android.app.Activity;
import android.os.Bundle;

public class EditConfigActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
    }

}
