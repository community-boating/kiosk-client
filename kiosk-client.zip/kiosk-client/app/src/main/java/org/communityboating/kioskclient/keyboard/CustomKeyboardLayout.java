package org.communityboating.kioskclient.keyboard;

import android.graphics.Canvas;

public class CustomKeyboardLayout {



    public static class CustomKeyboardKey{
        float top, left, right, bottom;
        int code;
        public void drawKey(Canvas canvas){

        }
    }

}
