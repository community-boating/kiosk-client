package org.communityboating.kioskclient.activity.newguest;

import org.communityboating.kioskclient.R;
import org.communityboating.kioskclient.progress.newguest.ProgressStateNewGuestPhone;

public class NewGuestPhoneActivity extends GenericPhoneActivity<ProgressStateNewGuestPhone> {

    @Override
    public int getTitleTextID(){
        return R.string.act1_desc;
    }

}
