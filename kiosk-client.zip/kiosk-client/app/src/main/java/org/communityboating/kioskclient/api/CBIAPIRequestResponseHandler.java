package org.communityboating.kioskclient.api;

import org.json.JSONObject;

public interface CBIAPIRequestResponseHandler {

    public void handleCBIAPIRequestResponse(JSONObject response);

}
