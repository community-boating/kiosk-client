package org.communityboating.kioskclient.activity;

public class NavButtonActivity extends BaseActivity implements NavButtonListener {



    @Override
    public void handleBackClick() {

    }

    @Override
    public void handleCancelClick() {

    }

    @Override
    public void handleHelpClick() {

    }
}
