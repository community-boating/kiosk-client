package org.communityboating.kioskclient.progress.validator;

public interface ProgressStateValueValidator {

    public String isValueValid(String value);

}
