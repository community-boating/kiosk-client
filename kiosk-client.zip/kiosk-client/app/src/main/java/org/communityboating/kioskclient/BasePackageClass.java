package org.communityboating.kioskclient;

public class BasePackageClass {
}
