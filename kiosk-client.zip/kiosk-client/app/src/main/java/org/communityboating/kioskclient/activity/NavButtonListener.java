package org.communityboating.kioskclient.activity;

public interface NavButtonListener {

    void handleBackClick();
    void handleCancelClick();
    void handleHelpClick();

}
