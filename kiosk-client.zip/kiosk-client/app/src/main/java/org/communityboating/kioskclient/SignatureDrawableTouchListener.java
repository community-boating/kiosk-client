package org.communityboating.kioskclient;

import android.view.MotionEvent;
import android.view.View;

public class SignatureDrawableTouchListener {

    //private SignatureDrawable signatureDrawable;

    //public SignatureDrawableTouchListener(SignatureDrawable signatureDrawable){
    //    this.signatureDrawable = signatureDrawable;
    //}

    //@Override
    //public boolean onTouch(View v, MotionEvent event) {
    //    return this.signatureDrawable.handleOnTouch(v, event);
    //}
}
